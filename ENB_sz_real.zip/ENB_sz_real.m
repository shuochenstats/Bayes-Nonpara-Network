%% normalized conn 
Rcorf=Test_Efis;
X=zscore(Rcorf,[ ],2);

W=X*X'; % figure; imagesc(W./59); colorbar; colormap jet;
figure;hist(squareform(W -diag(diag(W))),40)
% move null distribution of W to zero
W_vec=squareform(W -diag(diag(W)));
W_vec1=W_vec-0.185*59;
W_vec1(W_vec1<-59)=-59;
W=squareform(W_vec1)+eye(4005)*59;
figure;h0=histogram(squareform(W -diag(diag(W)))./59,40)
h0.Normalization = 'probability';
h0.BinWidth = 0.025;

%intialize...
G=90;
R=[1:G]; % Region;

A=tril(ones(G,G),-1);
[I,J] = ind2sub([G, G],find(A==1)); % I and J index the region pair, 19306;

K=ones(1,90);         % labels of the communities of Regions... K=[1:116];
%K=[ones(1,40),ones(1,40)*2,ones(1,36)*3];



subj_n=60
p=0.5;

dgW=W(1,1)*(1/(1-p));% element subject to the size of W sub matrix 
%smW=sum(sum(W))-sum(diag(W)); % test sum(sum(.3*eye(5)+.7))-5   is 0.7*20
% X are all standarized, so Gaussian graphical model...
para=[];
M=5000
for m=1:M, %mcmc loop, for each mcmc we record 2 things, Adjacency of GxG and lik all data...
    for g=1:G,
        %remove g from K, then assign to any existing cluster or new cluster and
        %calculate probability...
        Lik=[];K1=K;K1(g)=[]; %K1=the cluster remove g;
        K_label=unique(K1); % the labels of cluster;
        for c=1:length(unique(K1)), % assign region to existing clusters, and calculate likelihood.
            
            K(g)=K_label(c); %label the K...; we reset K here if g alone, the #K -1
            %assigned region change the cov of edges then calculate lik
            K_sets=[]; % how many edges are in cluster after assigning...
            nK=length(unique(K));
            Det=[];TR=[]; % reuse for each cluster assignment, a vector for a assignment
            for k=1:nK,  %for each cluster after assignment...
                set_k=find(K==K_label(k));% for each subset, we check how many edges are included
                %tic
                ind_pool=[]; % search index of the edges in the same cluster
                for i=1:length(I),

                    w=prod(single(ismember([I(i),J(i)],set_k)));
                    if w
                        ind_pool=[ind_pool,i]; % for example, 50 nodes will include 1225 edges in the communities
                    end

                end
                %toc
                bn1=length(ind_pool); %bn1=3

                % for likelihood and we need calculate the determint and
                % trace of tr(inv(Sigma)W) for the ind_pool...

                % log determinat:
                Det(k)=-subj_n/2*(log(1-p+bn1*p)+(bn1-1)*log(1-p)); % tested det
                TR(k)=-.5*(dgW*bn1-(sum(sum(W(ind_pool,ind_pool))))*(p/(1-p)/(1-p+bn1*p)));
                % (sum(sum(W(ind_pool,ind_pool))))
                %TR(k)=-trace((1/(1-p))*(eye(bn1)-p/(1-p+bn1*p))*W(ind_pool,ind_pool))*0.5;
       
                %toc (1/(1-p)).*(eye(bn1)-p/(1-p+bn1*p))
                %inv((1-p).*eye(bn1)+p)
                K_sets=[K_sets, ind_pool];

            end % each luster
            % if g is assigned to a cluster, then the edges between clusters...
            ind_btw=find(ismember(1:length(I),K_sets)==0);
            lik_btw=-0.5*length(ind_btw)*W(1,1);
            Lik(c)=sum(Det)+sum(TR)+lik_btw;
            % measure the size of each edge cluster, computation. blk size
            %bn=cellfun(@length, K_sets);

        end % end assigning to each cluster...
        
        % Assigning to a new cluster...
        K(g)=max(K_label)+1;
        K_label=unique(K); 
       
        K_sets=[];
        nK=length(unique(K));
        Det=[];TR=[];
        for k=1:nK,  %for each cluster after assignment...
            set_k=find(K==K_label(k));% for each subset, we check how many edges are included
            %tic
            ind_pool=[]; % search index of the edges in the same cluster
            for i=1:length(I),

                w=prod(single(ismember([I(i),J(i)],set_k)));
                if w
                    ind_pool=[ind_pool,i]; % for example, 50 nodes will include 1225 edges in the communities
                end

            end
            bn1=length(ind_pool); %bn1=3

            % for likelihood and we need calculate the determint and
            % trace of tr(inv(Sigma)W) for the ind_pool...

            % log determinat:
            Det(k)=-subj_n/2*(log(1-p+bn1*p)+(bn1-1)*log(1-p)); % tested det
            TR(k)=-.5*(dgW*bn1-(sum(sum(W(ind_pool,ind_pool))))*(p/(1-p)/(1-p+bn1*p)));
            %toc (1/(1-p)).*(eye(bn1)-p/(1-p+bn1*p))
            %inv((1-p).*eye(bn1)+p)
            K_sets=[K_sets, ind_pool];

        end % each luster
        % then the edges between clusters...
        
        ind_btw=find(ismember(1:length(I),K_sets)==0);
        lik_btw=-0.5*length(ind_btw)*W(1,1);
        Lik(c+1)=sum(Det)+sum(TR)+lik_btw; % not right for g was alone, then new alone again 
        
        Lik_norm=Lik-median(Lik);
        [lik_norm_max,lik_norm_maxid]=max(Lik-median(Lik))
        if lik_norm_max>100
           K(g)=K_label(lik_norm_maxid);
           
        else
            P=exp(Lik_norm)/sum(exp(Lik_norm))
            K(g)=K_label(mnrnd(1,P)==1); % label of cluster;
        end
         tabulate(K)
         para.K(m,:,g)=K;
         para.lik(m,g)=max(Lik);
         m
         g
    end % for regions assigned g 
         % mcmc
         %tabulate(K)
%         if m>500 
%         para.K(m-500,g)=K;
%         para.lik(m-500,g)=lik_norm_max;
%         end
        

end
K_tab=tabulate(K);
[K_2s,K_2I]=sort(K_tab(:,2),'descend');
K_tabs=K_tab(K_2I,:)

K_lab=K_tabs(K_tabs(:,2)>0,1);
K_roi=[]

for i=1:length(K_lab),
    K_roi=[K_roi,find(K==K_lab(i))];
end        
Test_Efis_mean=squareform(mean(Test_Efis'));
figure;imagesc(Test_Efis_mean ); colormap jet;
figure;imagesc(Test_Efis_mean(K_roi,K_roi)); colormap jet;

figure;imagesc(Test_Wn(K_roi,K_roi));colorbar
colormap jet
K_roi1=K_roi;
K_roi1(1:37)=[17,18,19,20,29,30,33,34,57,58,67,68,79,80,81,82,1,2,3,4,7,8,11,13,14,16,24,25,35,36,43,47,59,60,63,64,86];
figure;imagesc(Test_Wn(K_roi1,K_roi1));colorbar

figure;imagesc(Test_Efis_mean(K_roi1,K_roi1)); colormap jet;

colormap jet
 kmap=[ones(90,1), squeeze(para.K(5,:,:)) squeeze(para.K(10,:,:))]; 
       % matrix to draw
 figure;
 imagesc(kmap); 
 %mean Fisher's Z transformed correlation
 figure;imagesc(Test_Efis_mean(K_roi1,K_roi1)); colormap jet;
Test_Efis_meanctrl=squareform(mean(Test_Efis(:,1:30)'));
Test_Efis_meancase=squareform(mean(Test_Efis(:,31:60)'));
 figure;imagesc(Test_Efis_meanctrl(K_roi1,K_roi1)); colormap jet;
  figure;imagesc(Test_Efis_meancase(K_roi1,K_roi1)); colormap jet;
  % plot the difference test statistic
 figure;imagesc(Test_Wn(K_roi1,K_roi1));colorbar ;colormap jet;
  
  %%
  
  % in-network correlation and out-network correlation
  
  
  

safe_cor1=Rcorf;
ind_pool0=[];
 ind_poolk=[]; % search index of the edges in the same cluster
            for i=1:length(I),

                w =prod(single(ismember([I(i),J(i)],find(K==2)))); % whether they belong to the same community
                
                
                if w
                    ind_poolk=[ind_poolk,i]; % for example, 50 nodes will include 1225 edges in the communities
                else
                    ind_pool0=[ind_pool0,i];
                end
                
            end
            
            
  ind_pool01=[];   
 ind_poolk1=[]; % search index of the edges in the same cluster
            for i=1:length(I),

                w =prod(single(ismember([I(i),J(i)],find(K==10)))); % whether they belong to the same community
                
                
                if w
                    ind_poolk1=[ind_poolk1,i]; % for example, 50 nodes will include 1225 edges in the communities
                else
                    ind_pool01=[ind_pool01,i];
                end
                
            end
   
            
            
  figure; imagesc(W([ind_poolk,ind_poolk1,intersect(ind_pool0,ind_pool01)],[ind_poolk,ind_poolk1,intersect(ind_pool0,ind_pool01);])./59); colorbar; colormap jet;
  
  
  pconcor_safe0=1-pdist(safe_cor1(ind_pool0,:),'correlation');
  pconcor_safe1=1-pdist(safe_cor1(ind_poolk,:),'correlation');
  figure; h1=histogram([pconcor_safe0]-0.185,40);
  hold on;
  h2=histogram([pconcor_safe1]-0.185,40);
  h1.Normalization = 'probability';
h1.BinWidth = 0.025;
h2.Normalization = 'probability';
h2.BinWidth = 0.025;
  
  mean(pconcor_safe1)
  null_size=size(safe_cor1(ind_poolk,:)).*size(safe_cor1(ind_pool0,:));
  null_size=null_size(1);
  pconcor_safe10=reshape(zscore(safe_cor1(ind_poolk,:),[ ],2)*zscore(safe_cor1(ind_pool0,:),[ ],2)'./subj_n,1, null_size);   

  figure;
  hist(pconcor_safe,40);
  xlim([-1,1])
  hold on;
  hist([pconcor_safe0 pconcor_safe10],40);
  hist(pconcor_safe1,40); 

 
  
  
  
  

hist(pconcor_safe0,40);
hist(pconcor_safe10,40);
hist(pconcor_safe1,40); 






h = findobj(gca,'Type','patch');
display(h)

set(h(1),'FaceColor','r','EdgeColor','k');
set(h(2),'FaceColor','b','EdgeColor','k');
set(h(3),'FaceColor','g','EdgeColor','k');


%kde plots
pts=[-1:0.01:1];
[f,xi] = ksdensity(pconcor_safe,pts);
[f1,xi] = ksdensity(pconcor_safe1,pts);
[f0,xi] = ksdensity(pconcor_safe0,pts);
[f10,xi] = ksdensity(pconcor_safe10,pts);


figure;
plot(xi,f,'g')
hold on;
plot(xi,f1,'r')
plot(xi,f0);
plot(xi,f10,'k');

%spatial distance of the 4005 edges 


%figure;plot(rand(1,length(W_vec1))*149+0.5,W_vec1,'.')



%% likelihood calcualtion for BF


S_v=squareform(W -diag(diag(W)))./59;

S_vth=S_v;
S_vth(S_v<0.6)=0;

figure;imagesc(squareform(S_vth)+eye(4005))
S_th=squareform(S_vth)+eye(4005);% S_th=squareform(S_v)+eye(4005);
S_thinv=inv(S_th);

logS_thdet= logdet(S_th);


lik_th=-60/2*(logS_thdet)-.5*trace(W*S_thinv)

%  -8.8352e+04


%%% cov_B=eye(4005);
W_n=W([ind_poolk,ind_poolk1,intersect(ind_pool0,ind_pool01)],[ind_poolk,ind_poolk1,intersect(ind_pool0,ind_pool01);]);

cov_B(ind_poolk,ind_poolk)=0.27;
cov_B(ind_poolk1,ind_poolk1)=0.27;
cov_B=cov_B-diag(cov_B)+eye(4005);
logcov_B=  (length([ind_poolk ind_poolk1])-1)*log(1-.27)+log(1+0.27*(length(ind_poolk)-1))+log(1+0.27*(length(ind_poolk)-1))

lik_th=-60/2* (logcov_B)-.5*trace(W_n*inv(cov_B))
%-3.6592e+04